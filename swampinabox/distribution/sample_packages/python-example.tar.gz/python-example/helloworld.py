def return_five(arg, five=5):
    return five

def foo():
    my_list = ['foo', 'bar', 'baz']
    print(my_list)
    return my_list[4]

print("Hello, World!")

a = 14
b = -1
c = 3
print(return_five(a))
print("a + c = ", a+c)

foo()

print("All done.")
