#include <stdio.h>

void main( int argc, char *argv[] )
{
	printf("Hello World!\n");
}
