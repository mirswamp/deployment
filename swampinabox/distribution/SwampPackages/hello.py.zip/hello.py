print 'Hello, world!'

print ('Thou shalt execute {0} before {1}.' % ('programs', 'kittens', 'turtles'))
