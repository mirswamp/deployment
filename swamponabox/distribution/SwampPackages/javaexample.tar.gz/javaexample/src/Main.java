
public class Main implements Runnable {
    public static float overstep() {
        float[] ff = new float[10];
        ff[20] = 2;
        return ff[0];
    }
    static String qq = "quiet";
    public static void main(String[] args) {
        if (args[0] != qq) {
            System.out.println("Hello World from Java");
        }
        float result = overstep();
    }
    public void run() {
        qq = "Loud";
    }
    public void finalize() {
        //clean up our mess
    }
}
